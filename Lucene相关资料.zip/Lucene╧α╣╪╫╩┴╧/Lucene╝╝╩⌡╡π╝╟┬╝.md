
Lucene技术点记录

1.数据总体分为两种:

 - 结构化数据：指具有固定格式或有限长度的数据，如数据库，元数据等
 - 非结构化数据：指不定长或无固定格式的数据，如邮件，word文档等磁盘上的文件

2.非结构化数据查询方法

（1）顺序扫描法(Serial Scanning): 文件一个个扫描，从文件头部到尾部进行扫描

（2）全文检索(Full-text Search)：

  - 主要包括索引引擎和搜索引擎，以字典(类似map)的形式来存储索引和数据的位置;

3.如何实现全文检索

 - 可以使用lucene，lucene是apache下的一个开放源代码的全文检索引擎工具，主要包括索引引擎和搜索引擎，部分文本分析引擎，lucene是一个工具包，不同于solr，solr是将lucene进行封装，从而更加便于使用

4.全文检索的优势

 - 相比较于传统使用的sql中的like查询操作，lucene(全文检索引擎工具)由于首先生成了索引，而主要核心也是针对索引进行搜索,从而使得速度比sql查询快得多.

5.Lucene实现全文检索的流程

备注(以磁盘文件索引为例)

 - 获得原始文档(信息采集)
 - 创建文档对象(Document)
 - 分析文档(分词)
 - 创建索引

	- 倒排索引结构：创建索引是对语汇单元(关键词)索引，通过词语找文档

 - 查询索引: 根据关键字搜索索引，再根据索引找到对应的文档,从而找到要搜索的内容 

	- 用户查询接口: Lucene不提供制作用户搜索界面的功能，需要根据自己的需求开发搜索界面;
	- 创建查询: 用户输入查询关键字执行搜索之前需要先构建一个查询对象，查询对象中可以指定查询要搜索的Field文档域、查询关键字等，查询对象会生成具体的查询语法;
	- 执行查询: 根据查询语法在倒排索引词典表中分别找出对应搜索词的索引，从而找到索引所链接的文档链表;
	- 渲染结果： 展示给用户进行查看，高亮显示等效果


6.Field域的属性

 - 是否分析: 要对域的内容进行查询，则要分析;
 - 是否索引: 是否生成索引;
 - 是否存储: 凡是要从document中进行获取的Field都要存储;

7.Lucene工程涉及到的jar包

Lucene包：lucene-core-4.10.3.jar、lucene-analyzers-common-4.10.3.jar、lucene-queryparser-4.10.3.jar

其它包：
commons-io-2.4.jar、junit-4.9.jar



7.Lucene功能列举

 - 创建索引库，涉及到的类有IndexWriterConfig、IndexWriter、FSDirectory,使用Luke工具查看索引文件(二进制文件)
 - 查询索引，涉及到的类有FSDirectory、DirectoryReader、IndexReader、IndexSearcher、TermQuery、TopDocs 
 - 支持中文分析器
 	
	7.1. Lucene自带中文分词器

	- StandardAnalyzer(单字分词器)
	- CJKAnalyzer(二分法分词，按两个字进行切分)
	- SmartChineseAnalyzer(中文分词器，但扩展性差，扩展词库，禁用词库和同义词库等不好处理)
	
	7.2. 第三方中文分析器

	- paoding、mmseg4j、IK-analyzer、ansj_seg、imdict-chinese-analyzer、Jcseg、

 - 索引库的维护
 
	- 索引库添加document对象；
	- 删除索引库中所有的索引；
	- 指定查询条件进行删除;
	- 索引库修改document(原理: 先删除再添加);

 - 索引库的查询

	1.可通过两种方法创建查询对象

	- 使用Lucene提供的Query子类来查询;
	- 使用QueryParse解析查询表达式

		```java

			QueryParser parser = new QueryParser("filecontent", new IKAnalyzer());
			Query parse = parser.parse("notice");

		```

	2.Query子类

	- TermQuery: 精确查询;
	- NumericRangeQuery: 数字范围查询;
	- BooleanQuery: 组合查询条件;

		```

			Occur.MUST：必须满足此条件，相当于and
			Occur.SHOULD：应该满足，但是不满足也可以，相当于or
			Occur.MUST_NOT：必须不满足。相当于not

		```
	- MatchAllDocsQuery: 查询索引目录中的所有文档

	3.QueryParse子类

	- MulitFieldQueryParser: 可以指定多个默认搜索域

- Lucene各功能的代码示范

 	- 创建索引
		
		```java

			//创建索引
			@Test
			public void createIndex() throws IOException {
				
				FSDirectory directory = FSDirectory.open(new File("D:\\project\\lucene_index"));
				//分词器
				StandardAnalyzer analyzer = new StandardAnalyzer(); 
				
				//索引IndexWriter的配置
				IndexWriterConfig config = new IndexWriterConfig(Version.LATEST, analyzer);
				//indexWriter索引类
				IndexWriter indexWriter = new IndexWriter(directory,config); 
				
				File dir = new File("d:\\project\\lucene_document");
				
				for (File file:dir.listFiles()){
					//获取文件中的信息
					String fileName = file.getName();
					String fileContent = FileUtils.readFileToString(file); 
					String filePath = file.getPath();
					long fileSize = FileUtils.sizeOf(file);
					//创建域
					Field nameField = new TextField("filename",fileName,Store.YES);
					Field contentField = new TextField("filecontent",fileContent,Store.YES);
					Field pathField = new StoredField("filepath", filePath);
					Field sizeField = new LongField("filesize", fileSize, Store.YES);
					
					Document document = new Document();
					document.add(nameField);
					document.add(contentField);
					document.add(pathField);
					document.add(sizeField);
					
					//创建索引，并写入索引库
					indexWriter.addDocument(document);
				}
				//关闭IndexWriter
				indexWriter.close();
				
			}
		```

	- 查询索引

		```java

			// 查询索引
			@Test
			public void searchIndex() throws IOException {
				
				//指定索引库存放的路径
				FSDirectory directory = FSDirectory.open(new File("D:\\project\\lucene_index"));
				
				//创建索引读取的对象
				IndexReader indexReader = DirectoryReader.open(directory);
				IndexSearcher indexSearcher = new IndexSearcher(indexReader); 
				
				//创建查询
				Query query = new TermQuery(new Term("filecontent","some"));
				
				TopDocs topDocs = indexSearcher.search(query, 10);
				
				System.out.println("查询结果的总条数： " + topDocs.totalHits);
				
				for (ScoreDoc scoreDoc: topDocs.scoreDocs){
					
					Document document = indexSearcher.doc(scoreDoc.doc);
					
					System.out.println("名称： " + document.get("filename"));
					//System.out.println("内容： " + document.get("filecontent"));
					System.out.println("路径: " + document.get("filepath"));
					//System.out.println("大小： " + document.get("filesize")); 
				}
				indexReader.close();
			}
		```

	- 分词器的分词效果

		```java

			//分词器的分词效果
			@Test
			public void testTokenStream() throws IOException{ 
				
				Analyzer analyzer = new StandardAnalyzer(); 	//单字分词器
				
				TokenStream tokenStream = analyzer.tokenStream("test"
						,"The Spring Framework provides a comprehensive programming and configuration model.");
				//添加一个引用，可以获得每一个关键词
				CharTermAttribute charTermAttribute = tokenStream.addAttribute(CharTermAttribute.class);
				//添加一个偏移量的引用，记录关键词的开始位置及结束位置
				OffsetAttribute offsetAttribute = tokenStream.addAttribute(OffsetAttribute.class);
				//将指针调整到列表的头部
				tokenStream.reset();
				
				while (tokenStream.incrementToken()){
					//关键词的起始位置
					System.out.println("开始 位置 ： " + offsetAttribute.startOffset());
					//取关键词
					System.out.println("关键词： " + charTermAttribute);
					//关键词的结束位置
					System.out.println("结束 位置： " + offsetAttribute.endOffset() );
					
				}
				tokenStream.close();
			}
		```

	- 索引库的维护

		```java

			/**向索引库添加document对象*/
			@Test
			public void addDocument() throws IOException {
				
				IndexWriter indexWriter = getIndexWriter();
				Document document = new Document();
				
				document.add(new TextField("filename","新添加的文档名称",Store.YES));
				document.add(new TextField("filecontent","新添加的文档内容01",Store.NO)); 
				document.add(new TextField("filecontent", "新添加的文档内容02",Store.YES));
				document.add(new TextField("filecontent1", "新添加的文档内容03",Store.YES));
				indexWriter.addDocument(document);
				
				indexWriter.close();
				
			}
			
			@Test
			/**删除全部索引*/
			public void deleteAllIndex() throws IOException{
				
				IndexWriter indexWriter = getIndexWriter();
				indexWriter.deleteAll();
				indexWriter.close();
			}
			
			/**根据条件删除索引*/
			@Test
			public void deleteIndexByQuery() throws IOException {
				IndexWriter indexWriter = getIndexWriter();
				Query query = new TermQuery(new Term("filecontent","http"));
				indexWriter.deleteDocuments(query);
				indexWriter.close();
			}
			
			@Test
			/**索引库的修改*/
			public void updateIndex() throws IOException{
				
				IndexWriter indexWriter = getIndexWriter();
				
				Document document = new Document();
				document.add(new TextField("filename", "今天 元宵节", Store.YES));
				document.add(new TextField("filecontent", "今天正月 15 元宵节",Store.YES)); 
				
				indexWriter.updateDocument(new Term("filecontent","one"), document);
				indexWriter.close();
			}
			
			/**专门提供indexWriter对象*/
			public IndexWriter getIndexWriter() {
				IndexWriter indexWriter = null;
				try {
					//索引存放的位置
					FSDirectory directory = FSDirectory.open(new File("D:\\project\\lucene_index"));
					//生成索引的配置
					IndexWriterConfig config = new IndexWriterConfig(Version.LATEST, new IKAnalyzer());
							
					indexWriter = new IndexWriter(directory, config);
				} catch (IOException e) { 
					//e.printStackTrace();
				}
				return indexWriter;
			}
		```

	- 使用QuqeyParse查询

		```java

			/**使用QuqeyParse查询*/
			@Test
			public void testQueryParse() throws ParseException, IOException {
			
				IndexSearcher searcher = getIndexSearcher();
				QueryParser parser = new QueryParser("filecontent", new IKAnalyzer());
				Query parse = parser.parse("notice");
				
				TopDocs docs = searcher.search(parse, 10);
				
				System.out.println("查询到的条数 ： " + docs.totalHits); 
				for(ScoreDoc scoreDoc : docs.scoreDocs) {
					Document document = searcher.doc(scoreDoc.doc);
					System.out.println("文件名称为： "+ document.get("filename"));
				}
				
			}
			
			@Test
			/**使用MultiFieldQueryParser指定多个默认搜索域*/
			public void testMultiFieldQueryParser() throws Exception{
				
				IndexSearcher indexSearcher = getIndexSearcher();
				
				String[] fields = {"filename", "filecontent"};
				//创建一个MulitFiledQueryParser对象
				MultiFieldQueryParser queryParser = new MultiFieldQueryParser(fields, new IKAnalyzer());
				Query query = queryParser.parse("solrconfig and http");
				System.out.println(query);
				//执行查询
				TopDocs docs = indexSearcher.search(query, 10);
				
				System.out.println("查询到的条数 ： " + docs.totalHits); 
				for(ScoreDoc scoreDoc : docs.scoreDocs) {
					Document document = indexSearcher.doc(scoreDoc.doc);
					System.out.println("文件名称为： "+ document.get("filename"));
				}
				
			}
			
			/**专门提供IndexSearcher对象*/
			public IndexSearcher getIndexSearcher() {
				IndexSearcher searcher = null;
				try {
					//索引存放的位置
					FSDirectory directory = FSDirectory.open(new File("D:\\project\\lucene_index"));
					
					DirectoryReader reader = DirectoryReader.open(directory);
					searcher = new IndexSearcher(reader);
					
				} catch (IOException e) { 
					//e.printStackTrace();
				}
				return searcher;
			}
		```



###另外

1.爬虫或蜘蛛(信息采集)：lucene不提供信息采集，可以通过开源工具来获取

 - Nutch : 包括大规模爬虫工具，能够抓取和分辨web网站数据;
 - jsoup : 可直接解析某个URL地址、HTML文本内容,类似于jQuery的操作方法来取出和操作数据;
 - heritrix : 其最出色之处在于它良好的可扩展性，方便用户实现自己的抓取逻辑


2.使用luke工具查看索引，当我们对索引库进行了修改(原理：先删除后增加)后，luke可能来不及更新，导致索引词还是在的，只是对应的数据已经不存在咯, 也可能是索引词本来就没被删除，只是其对应的数据被删除了 。



